
# Demonstration of dictionary inbuilt functions

# Creating a dictionary
sample_dict = {"a": 1, "b": 2, "c": 3}

# Accessing, updating, and setting defaults
sample_dict["d"] = 4
print("After setting new key:", sample_dict)
print("Set default for 'e':", sample_dict.setdefault("e", 5))
print("Dictionary now:", sample_dict)

# Removing and copying
sample_dict.pop("b")
sample_dict_copy = sample_dict.copy()
print("After pop and copy:", sample_dict, sample_dict_copy)

# Dictionary methods
print("Keys:", list(sample_dict.keys()))
print("Values:", list(sample_dict.values()))
print("Items:", list(sample_dict.items()))
