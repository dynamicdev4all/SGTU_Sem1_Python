
# Demonstration of set inbuilt functions

# Creating a set
sample_set = {1, 2, 3, 4}

# Adding and discarding elements
sample_set.add(5)
sample_set.discard(3)
print("After add and discard:", sample_set)

# Set operations
another_set = {3, 4, 5, 6}
print("Union:", sample_set.union(another_set))
print("Intersection:", sample_set.intersection(another_set))
print("Symmetric difference:", sample_set.symmetric_difference(another_set))

# Checking relations
print("Is subset:", sample_set.issubset(another_set))
print("Is superset:", sample_set.issuperset({5}))
