
# Demonstration of list inbuilt functions

# Creating a list
sample_list = [1, 2, 3, 4, 5]

# Appending, extending, and inserting elements
sample_list.append(6)
sample_list.extend([7, 8])
sample_list.insert(0, 0)
print("After append, extend, and insert:", sample_list)

# Removing and reversing
sample_list.remove(4)
sample_list.reverse()
print("After remove and reverse:", sample_list)

# Counting and finding index
print("Count of 3:", sample_list.count(3))
print("Index of 2:", sample_list.index(2))
