
# Demonstration of string inbuilt functions

# Creating a string
sample_string = "  Hello, World! "

# Converting to uppercase and lowercase
print("Uppercase:", sample_string.upper())
print("Lowercase:", sample_string.lower())

# Finding substrings and replacing
print("Find 'World':", sample_string.find("World"))
print("Replace 'World' with 'Python':", sample_string.replace("World", "Python"))

# Stripping whitespace and splitting
print("Stripped:", sample_string.strip())
print("Split by comma:", sample_string.split(","))

# Checking content
print("Is alpha:", "Hello".isalpha())
print("Is digit:", "123".isdigit())
