
# Demonstration of tuple inbuilt functions

# Creating a tuple
sample_tuple = (1, 2, 3, 4, 5, 3)

# Counting occurrences of an element
print("Count of 3:", sample_tuple.count(3))

# Finding the index of an element
print("Index of 4:", sample_tuple.index(4))
